import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SeccondPage } from './seccond';

@NgModule({
  declarations: [
    SeccondPage,
  ],
  imports: [
    IonicPageModule.forChild(SeccondPage),
  ],
})
export class SeccondPageModule {}
